-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 26, 2018 at 03:03 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pollsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` text NOT NULL,
  `password` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('admin1', '1234'),
('admin2', '5678');

-- --------------------------------------------------------

--
-- Table structure for table `candidates`
--

CREATE TABLE `candidates` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `candidates`
--

INSERT INTO `candidates` (`id`, `name`, `created`, `modified`, `status`) VALUES
(1, 'Charlie', '2018-05-07 11:29:31', '2018-05-07 11:29:31', 1),
(2, 'Mary', '2018-05-07 11:34:09', '2018-05-07 11:35:23', 1),
(3, 'Grey', '2018-05-07 11:38:31', '2018-05-07 11:38:31', 1),
(4, 'Pierre', '0000-00-00 00:00:00', '2018-05-23 14:34:06', 0),
(5, 'werre', '2018-05-23 16:17:56', '2018-05-23 17:04:06', 1);

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `name` text NOT NULL,
  `gender` text NOT NULL,
  `reg_no` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`name`, `gender`, `reg_no`, `email`, `message`) VALUES
('willy', 'male', 'TU01-IC211-0187/2014', 'willy@gmail.com', 'not all candidates were in the voting page'),
('willy', 'male', 'TU01-IC211-0187/2014', 'willy@gmail.com', 'heyyy'),
('Maureen Jebet', 'Female', 'TU01-IC211-0218/2014', 'maureenjune16@gmail.com', 'Nice');

-- --------------------------------------------------------

--
-- Table structure for table `election`
--

CREATE TABLE `election` (
  `name` text NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `election`
--

INSERT INTO `election` (`name`, `date`) VALUES
('SATTU', '2018-06-12');

-- --------------------------------------------------------

--
-- Table structure for table `polls`
--

CREATE TABLE `polls` (
  `id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` enum('1','0') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `polls`
--

INSERT INTO `polls` (`id`, `subject`, `created`, `modified`, `status`) VALUES
(1, 'chairperson', '2018-05-07 11:29:31', '2018-05-07 11:29:31', '1');

-- --------------------------------------------------------

--
-- Table structure for table `polls option`
--

CREATE TABLE `polls option` (
  `id` int(11) NOT NULL,
  `poll_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` enum('1','0') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `polls option`
--

INSERT INTO `polls option` (`id`, `poll_id`, `name`, `created`, `modified`, `status`) VALUES
(1, 1, 'Charlie', '2018-05-07 11:29:31', '2018-05-07 11:29:31', '1'),
(2, 1, 'Mary', '2018-05-07 11:35:39', '2018-05-07 11:35:39', '1'),
(3, 1, 'Grey', '2018-05-07 11:40:59', '2018-05-07 11:40:59', '1');

-- --------------------------------------------------------

--
-- Table structure for table `poll votes`
--

CREATE TABLE `poll votes` (
  `reg_no` varchar(255) NOT NULL,
  `chairperson` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `poll votes`
--

INSERT INTO `poll votes` (`reg_no`, `chairperson`) VALUES
('TU01-IC211-0218/2014', 'Grey');

-- --------------------------------------------------------

--
-- Table structure for table `voters`
--

CREATE TABLE `voters` (
  `voter_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `reg_no` varchar(255) NOT NULL,
  `course` text NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(32) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `voters`
--

INSERT INTO `voters` (`voter_id`, `name`, `reg_no`, `course`, `email`, `password`, `active`) VALUES
(1, 'annette', 'TU01-ic211-0178/2014', 'Bsc IT', 'annetteO@gmail.com', 'annettee', 0),
(2, 'Mia', 'TU01-BE211-0432/2014', 'BPS', 'mhsk@gmail.com', 'mia', 0),
(3, 'willy', 'TU01-IC211-0187/2014', 'BIT', 'willy@gmail.com', 'willy', 0),
(4, 'Maureen Jebet', 'TU01-IC211-0218/2014', 'BIT', 'maureenjune16@gmail.com', 'mj16', 0),
(5, 'Grace Kadogo', 'TU01-IC211-0427/2015', 'MCS', 'grace@gmail.com', 'grace', 0),
(6, 'poiu', 'TU01-IC211-0189/2014', 'BIT', 'poiu@gmail.com', '123', 0);

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

CREATE TABLE `votes` (
  `reg_no` varchar(255) NOT NULL,
  `chairperson` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `votes`
--

INSERT INTO `votes` (`reg_no`, `chairperson`) VALUES
('TU01-IC211-0218/2014', 'Mary'),
('TU01-IC211-0187/2014', 'Grey'),
('TU01-IC211-0187/2014', 'Grey'),
('TU01-IC211-0427/2015', 'Charlie'),
('TU01-IC211-0218/2014', 'Charlie'),
('TU01-IC211-0218/2014', 'Charlie'),
('TU01-IC211-0218/2014', 'Charlie'),
('TU01-IC211-0218/2014', 'Charlie'),
('TU01-IC211-0218/2014', 'Charlie'),
('TU01-IC211-0218/2014', 'Charlie');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `candidates`
--
ALTER TABLE `candidates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `polls`
--
ALTER TABLE `polls`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `polls option`
--
ALTER TABLE `polls option`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `poll votes`
--
ALTER TABLE `poll votes`
  ADD PRIMARY KEY (`reg_no`);

--
-- Indexes for table `voters`
--
ALTER TABLE `voters`
  ADD PRIMARY KEY (`voter_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `polls`
--
ALTER TABLE `polls`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `voters`
--
ALTER TABLE `voters`
  MODIFY `voter_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
