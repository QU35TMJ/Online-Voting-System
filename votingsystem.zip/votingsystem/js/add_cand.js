function f1()
{
  var p=document.add.p.value;
  if(p=="")
  {
    window.alert("Please enter president name !");
    	document.add.p.focus();
    return false;
  }
}

function f2()
{
  var vp_i=document.add.vp_i.value;
  if(vp_i=="")
  {
    window.alert("Please enter VP Internal name !");
    	document.add.vp_i.focus();
    return false;
  }
}
function f3()
{
  var vp_e=document.add.vp_e.value;
  if(vp_e=="")
  {
    window.alert("Please enter VP External name !");
    	document.add.vp_e.focus();
    return false;
  }
}
function f4()
{
  var secre=document.add.secre.value;
  if(secre=="")
  {
    window.alert("Please enter Secretary name !");
    	document.add.secre.focus();
    return false;
  }
}

function f5()
{
  var treasu=document.add.treasu.value;
  if(treasu=="")
  {
    window.alert("Please enter Treasurer name !");
    	document.add.treasu.focus();
    return false;
  }
}


function f6()
{
  var audit=document.add.audit.value;
  if(audit=="")
  {
    window.alert("Please enter Auditor name !");
    	document.add.audit.focus();
    return false;
  }
}

function f7()
{
  var fyr=document.add.fyr.value;
  if(fyr=="")
  {
    window.alert("Please enter first year REP1 name !");
    	document.add.fyr.focus();
    return false;
  }
}

function f8()
{
  var fyre=document.add.fyre.value;
  if(fyre=="")
  {
    window.alert("Please enter First year REP2 name !");
    	document.add.fyre.focus();
    return false;
  }
}




function f9()
{
  var syr=document.add.syr.value;
  if(syr=="")
  {
    window.alert("Please enter Second year REP1 name !");
    	document.add.syr.focus();
    return false;
  }
}
function f10()
{
  var syre=document.add.syre.value;
  if(syre=="")
  {
    window.alert("Please enter Second year REP2 name !");
    	document.add.syre.focus();
    return false;
  }
}


/* Remove btn*/


function r1()
{
  var p=document.add.p.value;
  if(p=="")
  {
    window.alert("Please enter president name !");
    	document.add.p.focus();
    return false;
  }
}

function r2()
{
  var vp_i=document.add.vp_i.value;
  if(vp_i=="")
  {
    window.alert("Please enter VP Internal name !");
    	document.add.vp_i.focus();
    return false;
  }
}
function r3()
{
  var vp_e=document.add.vp_e.value;
  if(vp_e=="")
  {
    window.alert("Please enter VP External name !");
    	document.add.vp_e.focus();
    return false;
  }
}
function r4()
{
  var secre=document.add.secre.value;
  if(secre=="")
  {
    window.alert("Please enter Secretary name !");
    	document.add.secre.focus();
    return false;
  }
}

function r5()
{
  var treasu=document.add.treasu.value;
  if(treasu=="")
  {
    window.alert("Please enter Treasurer name !");
    	document.add.treasu.focus();
    return false;
  }
}


function r6()
{
  var audit=document.add.audit.value;
  if(audit=="")
  {
    window.alert("Please enter Auditor name !");
    	document.add.audit.focus();
    return false;
  }
}

function r7()
{
  var fyr=document.add.fyr.value;
  if(fyr=="")
  {
    window.alert("Please enter first year REP1 name !");
    	document.add.fyr.focus();
    return false;
  }
}

function r8()
{
  var fyre=document.add.fyre.value;
  if(fyre=="")
  {
    window.alert("Please enter First year REP2 name !");
    	document.add.fyre.focus();
    return false;
  }
}




function r9()
{
  var syr=document.add.syr.value;
  if(syr=="")
  {
    window.alert("Please enter Second year REP1 name !");
    	document.add.syr.focus();
    return false;
  }
}
function r10()
{
  var syre=document.add.syre.value;
  if(syre=="")
  {
    window.alert("Please enter Second year REP2 name !");
    	document.add.syre.focus();
    return false;
  }
}


